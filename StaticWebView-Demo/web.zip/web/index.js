
setTimeout(()=>{
    document.body.innerHTML = "<h1> load js successfullu</h1>"
},2000)
